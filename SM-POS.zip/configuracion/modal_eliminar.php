<form id="eliminarDatos">
<div class="modal fade modal-lg " id="dataDelete" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <input type="hidden" id="id_pais" name="id_pais">

    <p class="lead text-muted text-center" style="display: block;margin:10px">Desea borrar el cliente del sistema?</p>
      <div class="modal-footer">
        <button type="submit" class="btn btn-lg btn-primary">Borrar</button>

        <button type="button" class="btn btn-lg btn-default" data-dismiss="modal">Cancelar</button>

      </div>
    </div>
  </div>
</div>
</form>