<form id="guardarDatos22">
<div class="modal fade" id="dataRegister2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="exampleModalLabel">Nuevo Cliesssssnxxte2</h4>
      </div>
      <div class="modal-body">
			<div id="datos_ajax_register"></div>
          <div class="form-group">

            <input type="text" class="form-control"  placeholder="Nombre*" id="nombre" name="nombre" required >
		  </div>
		  <div class="form-group">
            <input type="text" class="form-control" id="codigo" name="codigo" placeholder="C.C / Número Identificación*" required maxlength="20">
          </div>
		  <div class="form-group">
            <input type="text" class="form-control" id="moneda" name="moneda" required placeholder="Dirección*">
          </div>
		  <div class="form-group">
            <input type="text" class="form-control" id="capital" name="capital" required maxlength="30" placeholder="Teléfono*" >
          </div>
		  <div class="form-group">
            <input type="text" class="form-control" id="continente" name="continente" required maxlength="15" placeholder="Email*" >
          </div>


      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary">Grabar</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>

      </div>
    </div>
  </div>
</div>
</form>